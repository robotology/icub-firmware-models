//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
//
// File: wrist_decoupler.cpp
//
// Code generated for Simulink model 'wrist_decoupler'.
//
// Model version                  : 6.6
// Simulink Coder version         : 9.8 (R2022b) 13-May-2022
// C/C++ source code generated on : Fri Mar 24 10:28:52 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "wrist_decoupler.h"
#include "rtwtypes.h"
#include <cmath>
#include <cstring>
#include <cfloat>
#include <stddef.h>
#define NumBitsPerChar                 8U

extern real_T rt_atan2d_snf(real_T u0, real_T u1);
extern real_T rt_remd_snf(real_T u0, real_T u1);

//===========*
//  Constants *
// ===========
#define RT_PI                          3.14159265358979323846
#define RT_PIF                         3.1415927F
#define RT_LN_10                       2.30258509299404568402
#define RT_LN_10F                      2.3025851F
#define RT_LOG10E                      0.43429448190325182765
#define RT_LOG10EF                     0.43429449F
#define RT_E                           2.7182818284590452354
#define RT_EF                          2.7182817F

//
//  UNUSED_PARAMETER(x)
//    Used to specify that a function parameter (argument) is required but not
//    accessed by the function body.

#ifndef UNUSED_PARAMETER
#if defined(__LCC__)
#define UNUSED_PARAMETER(x)                                      // do nothing
#else

//
//  This is the semi-ANSI standard way of indicating that an
//  unused function parameter is required.

#define UNUSED_PARAMETER(x)            (void) (x)
#endif
#endif

extern "C"
{
  real_T rtInf;
  real_T rtMinusInf;
  real_T rtNaN;
  real32_T rtInfF;
  real32_T rtMinusInfF;
  real32_T rtNaNF;
}

extern "C"
{
  //
  // Initialize rtNaN needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetNaN(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T nan = 0.0;
    if (bitsPerReal == 32U) {
      nan = rtGetNaNF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF80000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      nan = tmpVal.fltVal;
    }

    return nan;
  }

  //
  // Initialize rtNaNF needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetNaNF(void)
  {
    IEEESingle nanF = { { 0.0F } };

    nanF.wordL.wordLuint = 0xFFC00000U;
    return nanF.wordL.wordLreal;
  }
}

extern "C"
{
  //
  // Initialize the rtInf, rtMinusInf, and rtNaN needed by the
  // generated code. NaN is initialized as non-signaling. Assumes IEEE.
  //
  static void rt_InitInfAndNaN(size_t realSize)
  {
    (void) (realSize);
    rtNaN = rtGetNaN();
    rtNaNF = rtGetNaNF();
    rtInf = rtGetInf();
    rtInfF = rtGetInfF();
    rtMinusInf = rtGetMinusInf();
    rtMinusInfF = rtGetMinusInfF();
  }

  // Test if value is infinite
  static boolean_T rtIsInf(real_T value)
  {
    return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
  }

  // Test if single-precision value is infinite
  static boolean_T rtIsInfF(real32_T value)
  {
    return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
  }

  // Test if value is not a number
  static boolean_T rtIsNaN(real_T value)
  {
    boolean_T result = (boolean_T) 0;
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    if (bitsPerReal == 32U) {
      result = rtIsNaNF((real32_T)value);
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.fltVal = value;
      result = (boolean_T)((tmpVal.bitVal.words.wordH & 0x7FF00000) ==
                           0x7FF00000 &&
                           ( (tmpVal.bitVal.words.wordH & 0x000FFFFF) != 0 ||
                            (tmpVal.bitVal.words.wordL != 0) ));
    }

    return result;
  }

  // Test if single-precision value is not a number
  static boolean_T rtIsNaNF(real32_T value)
  {
    IEEESingle tmp;
    tmp.wordL.wordLreal = value;
    return (boolean_T)( (tmp.wordL.wordLuint & 0x7F800000) == 0x7F800000 &&
                       (tmp.wordL.wordLuint & 0x007FFFFF) != 0 );
  }
}

extern "C"
{
  //
  // Initialize rtInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T inf = 0.0;
    if (bitsPerReal == 32U) {
      inf = rtGetInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0x7FF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      inf = tmpVal.fltVal;
    }

    return inf;
  }

  //
  // Initialize rtInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetInfF(void)
  {
    IEEESingle infF;
    infF.wordL.wordLuint = 0x7F800000U;
    return infF.wordL.wordLreal;
  }

  //
  // Initialize rtMinusInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetMinusInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T minf = 0.0;
    if (bitsPerReal == 32U) {
      minf = rtGetMinusInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      minf = tmpVal.fltVal;
    }

    return minf;
  }

  //
  // Initialize rtMinusInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetMinusInfF(void)
  {
    IEEESingle minfF;
    minfF.wordL.wordLuint = 0xFF800000U;
    return minfF.wordL.wordLreal;
  }
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    int32_T tmp;
    int32_T tmp_0;
    if (u0 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u1 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = std::atan2(static_cast<real_T>(tmp), static_cast<real_T>(tmp_0));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }

  return y;
}

// Function for MATLAB Function: '<S2>/motors2quat'
real_T wrist_decoupler::maximum(const real_T x[3])
{
  real_T ex;
  int32_T idx;
  int32_T k;
  if (!rtIsNaN(x[0])) {
    idx = 1;
  } else {
    boolean_T exitg1;
    idx = 0;
    k = 2;
    exitg1 = false;
    while ((!exitg1) && (k < 4)) {
      if (!rtIsNaN(x[k - 1])) {
        idx = k;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }

  if (idx == 0) {
    ex = x[0];
  } else {
    ex = x[idx - 1];
    for (k = idx + 1; k < 4; k++) {
      real_T tmp;
      tmp = x[k - 1];
      if (ex < tmp) {
        ex = tmp;
      }
    }
  }

  return ex;
}

// Function for MATLAB Function: '<S2>/motors2quat'
real_T wrist_decoupler::minimum(const real_T x[3])
{
  real_T ex;
  int32_T idx;
  int32_T k;
  if (!rtIsNaN(x[0])) {
    idx = 1;
  } else {
    boolean_T exitg1;
    idx = 0;
    k = 2;
    exitg1 = false;
    while ((!exitg1) && (k < 4)) {
      if (!rtIsNaN(x[k - 1])) {
        idx = k;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }

  if (idx == 0) {
    ex = x[0];
  } else {
    ex = x[idx - 1];
    for (k = idx + 1; k < 4; k++) {
      real_T tmp;
      tmp = x[k - 1];
      if (ex > tmp) {
        ex = tmp;
      }
    }
  }

  return ex;
}

real_T rt_remd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (rtIsInf(u1)) {
    y = u0;
  } else {
    real_T q;
    if (u1 < 0.0) {
      q = std::ceil(u1);
    } else {
      q = std::floor(u1);
    }

    if ((u1 != 0.0) && (u1 != q)) {
      q = std::abs(u0 / u1);
      if (!(std::abs(q - std::floor(q + 0.5)) > DBL_EPSILON * q)) {
        y = 0.0 * u0;
      } else {
        y = std::fmod(u0, u1);
      }
    } else {
      y = std::fmod(u0, u1);
    }
  }

  return y;
}

// Function for MATLAB Function: '<S2>/motors2quat'
real_T wrist_decoupler::det(const real_T x[9])
{
  real_T A[9];
  real_T y;
  int8_T ipiv[3];
  boolean_T isodd;
  std::memcpy(&A[0], &x[0], 9U * sizeof(real_T));
  ipiv[0] = 1;
  ipiv[1] = 2;
  for (int32_T j = 0; j < 2; j++) {
    real_T smax;
    int32_T b_ix;
    int32_T iy;
    int32_T jj;
    jj = j << 2;
    iy = 3 - j;
    b_ix = 0;
    smax = std::abs(A[jj]);
    for (int32_T c_k = 2; c_k <= iy; c_k++) {
      real_T s;
      s = std::abs(A[(jj + c_k) - 1]);
      if (s > smax) {
        b_ix = c_k - 1;
        smax = s;
      }
    }

    if (A[jj + b_ix] != 0.0) {
      if (b_ix != 0) {
        iy = j + b_ix;
        ipiv[j] = static_cast<int8_T>(iy + 1);
        smax = A[j];
        A[j] = A[iy];
        A[iy] = smax;
        smax = A[j + 3];
        A[j + 3] = A[iy + 3];
        A[iy + 3] = smax;
        smax = A[j + 6];
        A[j + 6] = A[iy + 6];
        A[iy + 6] = smax;
      }

      iy = (jj - j) + 3;
      for (b_ix = jj + 2; b_ix <= iy; b_ix++) {
        A[b_ix - 1] /= A[jj];
      }
    }

    iy = 1 - j;
    b_ix = jj + 5;
    for (int32_T c_k = 0; c_k <= iy; c_k++) {
      smax = A[(c_k * 3 + jj) + 3];
      if (smax != 0.0) {
        int32_T c;
        c = (b_ix - j) + 1;
        for (int32_T ijA = b_ix; ijA <= c; ijA++) {
          A[ijA - 1] += A[((jj + ijA) - b_ix) + 1] * -smax;
        }
      }

      b_ix += 3;
    }
  }

  isodd = (ipiv[0] > 1);
  y = A[0] * A[4] * A[8];
  if (ipiv[1] > 2) {
    isodd = !isodd;
  }

  if (isodd) {
    y = -y;
  }

  return y;
}

// Function for MATLAB Function: '<S2>/motors2quat'
void wrist_decoupler::mldivide(const real_T A[9], const real_T B_0[3], real_T Y
  [3])
{
  real_T b_A[9];
  real_T a21;
  real_T maxval;
  int32_T r1;
  int32_T r2;
  int32_T r3;
  std::memcpy(&b_A[0], &A[0], 9U * sizeof(real_T));
  r1 = 0;
  r2 = 1;
  r3 = 2;
  maxval = std::abs(A[0]);
  a21 = std::abs(A[1]);
  if (a21 > maxval) {
    maxval = a21;
    r1 = 1;
    r2 = 0;
  }

  if (std::abs(A[2]) > maxval) {
    r1 = 2;
    r2 = 1;
    r3 = 0;
  }

  b_A[r2] = A[r2] / A[r1];
  b_A[r3] /= b_A[r1];
  b_A[r2 + 3] -= b_A[r1 + 3] * b_A[r2];
  b_A[r3 + 3] -= b_A[r1 + 3] * b_A[r3];
  b_A[r2 + 6] -= b_A[r1 + 6] * b_A[r2];
  b_A[r3 + 6] -= b_A[r1 + 6] * b_A[r3];
  if (std::abs(b_A[r3 + 3]) > std::abs(b_A[r2 + 3])) {
    int32_T rtemp;
    rtemp = r2;
    r2 = r3;
    r3 = rtemp;
  }

  b_A[r3 + 3] /= b_A[r2 + 3];
  b_A[r3 + 6] -= b_A[r3 + 3] * b_A[r2 + 6];
  Y[1] = B_0[r2] - B_0[r1] * b_A[r2];
  Y[2] = (B_0[r3] - B_0[r1] * b_A[r3]) - b_A[r3 + 3] * Y[1];
  Y[2] /= b_A[r3 + 6];
  Y[0] = B_0[r1] - b_A[r1 + 6] * Y[2];
  Y[1] -= b_A[r2 + 6] * Y[2];
  Y[1] /= b_A[r2 + 3];
  Y[0] -= b_A[r1 + 3] * Y[1];
  Y[0] /= b_A[r1];
}

// Model step function
void wrist_decoupler::step()
{
  real_T up[12];
  real_T b[9];
  real_T q[9];
  real_T ct[3];
  real_T st[3];
  real_T absx;
  real_T arg_idx_0;
  real_T arg_idx_1;
  real_T arg_idx_2;
  real_T b_tmp;
  real_T ct_0;
  real_T d_n;
  real_T n;
  real_T rtb_Product1;
  real_T yd_idx_0;
  real_T yd_idx_1;
  real_T yd_idx_2;
  int32_T b_k;
  int32_T idx;
  int32_T q_tmp;
  boolean_T exitg1;

  // Outputs for Atomic SubSystem: '<Root>/wrist_decoupler'
  // Outport: '<Root>/theta_star' incorporates:
  //   MATLAB Function: '<S1>/ypr2motors'

  // :  theta = [0;0;0];
  // :  q = Q*eul2rotm(deg2rad(ypr'))';
  rtY.theta_star[0] = 0.0;

  // MATLAB Function: '<S1>/ypr2motors' incorporates:
  //   Inport: '<Root>/ypr_star'

  yd_idx_0 = 0.017453292519943295 * rtU.ypr_star[0];
  d_n = std::cos(yd_idx_0);
  yd_idx_1 = std::sin(yd_idx_0);

  // Outport: '<Root>/theta_star' incorporates:
  //   MATLAB Function: '<S1>/ypr2motors'

  rtY.theta_star[1] = 0.0;

  // MATLAB Function: '<S1>/ypr2motors' incorporates:
  //   Inport: '<Root>/ypr_star'

  yd_idx_0 = 0.017453292519943295 * rtU.ypr_star[1];
  yd_idx_2 = std::cos(yd_idx_0);
  absx = std::sin(yd_idx_0);

  // Outport: '<Root>/theta_star' incorporates:
  //   MATLAB Function: '<S1>/ypr2motors'

  rtY.theta_star[2] = 0.0;

  // MATLAB Function: '<S1>/ypr2motors' incorporates:
  //   Inport: '<Root>/ypr_star'

  yd_idx_0 = 0.017453292519943295 * rtU.ypr_star[2];
  ct_0 = std::cos(yd_idx_0);
  yd_idx_0 = std::sin(yd_idx_0);
  b[0] = d_n * yd_idx_2;
  b_tmp = absx * yd_idx_0;
  b[3] = b_tmp * d_n - yd_idx_1 * ct_0;
  arg_idx_2 = absx * ct_0;
  b[6] = arg_idx_2 * d_n + yd_idx_1 * yd_idx_0;
  b[1] = yd_idx_1 * yd_idx_2;
  b[4] = b_tmp * yd_idx_1 + d_n * ct_0;
  b[7] = arg_idx_2 * yd_idx_1 - d_n * yd_idx_0;
  b[2] = -absx;
  b[5] = yd_idx_2 * yd_idx_0;
  b[8] = yd_idx_2 * ct_0;
  for (b_k = 0; b_k < 3; b_k++) {
    for (idx = 0; idx < 3; idx++) {
      q_tmp = 3 * idx + b_k;
      q[q_tmp] = 0.0;
      q[q_tmp] += rtConstP.pooled4[b_k] * b[idx];
      q[q_tmp] += rtConstP.pooled4[b_k + 3] * b[idx + 3];
      q[q_tmp] += rtConstP.pooled4[b_k + 6] * b[idx + 6];
    }
  }

  // :  m = [sqrt(q(1,1)^2+q(1,2)^2) sqrt(q(2,1)^2+q(2,2)^2) sqrt(q(3,1)^2+q(3,2)^2)]; 
  yd_idx_0 = std::sqrt(q[0] * q[0] + q[3] * q[3]);
  yd_idx_2 = std::sqrt(q[1] * q[1] + q[4] * q[4]);
  yd_idx_1 = std::sqrt(q[2] * q[2] + q[5] * q[5]);

  // :  if min(abs(m)) == 0
  st[0] = yd_idx_0;
  st[1] = yd_idx_2;
  st[2] = yd_idx_1;
  if (!rtIsNaN(yd_idx_0)) {
    idx = 1;
  } else {
    idx = 0;
    b_k = 2;
    exitg1 = false;
    while ((!exitg1) && (b_k < 4)) {
      if (!rtIsNaN(st[b_k - 1])) {
        idx = b_k;
        exitg1 = true;
      } else {
        b_k++;
      }
    }
  }

  if (idx == 0) {
    d_n = yd_idx_0;
  } else {
    d_n = st[idx - 1];
    for (b_k = idx + 1; b_k < 4; b_k++) {
      absx = st[b_k - 1];
      if (d_n > absx) {
        d_n = absx;
      }
    }
  }

  if (d_n == 0.0) {
    // Outport: '<Root>/out_of_range'
    // :  out_of_range = 1;
    rtY.out_of_range = 1.0;
  } else {
    // :  arg = [(PQ(1)-Pz(1)*q(1,3))/m(1); (PQ(2)-Pz(2)*q(2,3))/m(2); (PQ(3)-Pz(3)*q(3,3))/m(3)]; 
    arg_idx_0 = (0.5 - -0.57735026918962573 * q[6]) / yd_idx_0;
    arg_idx_1 = (0.087155742747658166 - -0.57735026918962573 * q[7]) / yd_idx_2;
    arg_idx_2 = (-0.49999999999999994 - -0.57735026918962573 * q[8]) / yd_idx_1;

    // :  if max(abs(arg)) > 1
    st[0] = std::abs(arg_idx_0);
    st[1] = std::abs(arg_idx_1);
    st[2] = std::abs(arg_idx_2);
    if (!rtIsNaN(st[0])) {
      idx = 1;
    } else {
      idx = 0;
      b_k = 2;
      exitg1 = false;
      while ((!exitg1) && (b_k < 4)) {
        if (!rtIsNaN(st[b_k - 1])) {
          idx = b_k;
          exitg1 = true;
        } else {
          b_k++;
        }
      }
    }

    if (idx == 0) {
      d_n = st[0];
    } else {
      d_n = st[idx - 1];
      for (b_k = idx + 1; b_k < 4; b_k++) {
        yd_idx_0 = st[b_k - 1];
        if (d_n < yd_idx_0) {
          d_n = yd_idx_0;
        }
      }
    }

    if (d_n > 1.0) {
      // Outport: '<Root>/out_of_range'
      // :  out_of_range = 1;
      rtY.out_of_range = 1.0;
    } else {
      // Outport: '<Root>/theta_star'
      // :  theta = atan2d(q(:,2),q(:,1))+[90; 90; 90;]-asind(arg);
      rtY.theta_star[0] = (57.295779513082323 * rt_atan2d_snf(q[3], q[0]) + 90.0)
        - 57.295779513082323 * std::asin(arg_idx_0);
      rtY.theta_star[1] = (57.295779513082323 * rt_atan2d_snf(q[4], q[1]) + 90.0)
        - 57.295779513082323 * std::asin(arg_idx_1);
      rtY.theta_star[2] = (57.295779513082323 * rt_atan2d_snf(q[5], q[2]) + 90.0)
        - 57.295779513082323 * std::asin(arg_idx_2);

      // Outport: '<Root>/out_of_range'
      // :  out_of_range = 0;
      rtY.out_of_range = 0.0;
    }
  }

  // Outputs for Atomic SubSystem: '<S1>/motors2ypr'
  // MATLAB Function: '<S2>/motors2quat' incorporates:
  //   Inport: '<Root>/theta_meas'

  // :  if isempty(T)
  // :  if isempty(singularity_reg)
  // :  theta_diff = theta_meas - [145; -90; 40];
  // :  for k=1:3
  // :  if max(abs(theta_diff)) < 5.0
  // :  while theta_diff(k) > 180.0
  for (arg_idx_0 = rtU.theta_meas[0] - 145.0; arg_idx_0 > 180.0; arg_idx_0 -=
       360.0) {
    // :  theta_diff(k) = theta_diff(k) - 360.0;
  }

  // :  while theta_diff(k) < -180.0
  while (arg_idx_0 < -180.0) {
    // :  theta_diff(k) = theta_diff(k) + 360.0;
    arg_idx_0 += 360.0;
  }

  st[0] = std::abs(arg_idx_0);

  // :  while theta_diff(k) > 180.0
  for (arg_idx_1 = rtU.theta_meas[1] - -90.0; arg_idx_1 > 180.0; arg_idx_1 -=
       360.0) {
    // :  theta_diff(k) = theta_diff(k) - 360.0;
  }

  // :  while theta_diff(k) < -180.0
  while (arg_idx_1 < -180.0) {
    // :  theta_diff(k) = theta_diff(k) + 360.0;
    arg_idx_1 += 360.0;
  }

  st[1] = std::abs(arg_idx_1);

  // :  while theta_diff(k) > 180.0
  for (arg_idx_2 = rtU.theta_meas[2] - 40.0; arg_idx_2 > 180.0; arg_idx_2 -=
       360.0) {
    // :  theta_diff(k) = theta_diff(k) - 360.0;
  }

  // :  while theta_diff(k) < -180.0
  while (arg_idx_2 < -180.0) {
    // :  theta_diff(k) = theta_diff(k) + 360.0;
    arg_idx_2 += 360.0;
  }

  st[2] = std::abs(arg_idx_2);
  if (maximum(st) < 5.0) {
    // :  singularity_reg = 0;
    rtDW.singularity_reg = 0.0;
  }

  // :  if singularity_reg
  if (rtDW.singularity_reg != 0.0) {
    // :  attitude = compact(T);
    absx = rtDW.T.a;
    yd_idx_2 = rtDW.T.b;
    yd_idx_1 = rtDW.T.c;
    yd_idx_0 = rtDW.T.d;

    // Outport: '<Root>/singularity'
    // :  singularity = singularity_reg;
    rtY.singularity = rtDW.singularity_reg;

    // :  cycles = 0;
    idx = 0;
  } else {
    int32_T b_cycles;
    boolean_T guard1 = false;

    // :  for cycles=1:200
    idx = 1;
    b_cycles = 0;
    guard1 = false;
    int32_T exitg2;
    do {
      exitg2 = 0;
      if (b_cycles < 200) {
        real_T up_tmp;
        real_T up_tmp_0;
        real_T up_tmp_1;
        real_T up_tmp_2;
        real_T up_tmp_3;
        real_T up_tmp_4;
        real_T up_tmp_5;
        idx = b_cycles + 1;

        // :  q = rotatepoint(T,Q);
        n = std::sqrt(((rtDW.T.a * rtDW.T.a + rtDW.T.b * rtDW.T.b) + rtDW.T.c *
                       rtDW.T.c) + rtDW.T.d * rtDW.T.d);
        d_n = rtDW.T.a / n;
        absx = rtDW.T.b / n;
        rtb_Product1 = rtDW.T.c / n;
        n = rtDW.T.d / n;
        up[0] = 0.0;
        up[1] = 0.0;
        up[2] = 0.0;
        std::memcpy(&up[3], &rtConstP.pooled4[0], 9U * sizeof(real_T));
        arg_idx_0 = ((d_n * up[0] - absx * up[3]) - rtb_Product1 * up[6]) - n *
          up[9];
        st[0] = ((d_n * up[3] + absx * up[0]) + rtb_Product1 * up[9]) - n * up[6];
        ct[0] = ((d_n * up[6] - absx * up[9]) + rtb_Product1 * up[0]) + n * up[3];
        yd_idx_0 = ((d_n * up[9] + absx * up[6]) - rtb_Product1 * up[3]) + n *
          up[0];
        arg_idx_1 = ((d_n * up[1] - absx * up[4]) - rtb_Product1 * up[7]) - n *
          up[10];
        st[1] = ((d_n * up[4] + absx * up[1]) + rtb_Product1 * up[10]) - n * up
          [7];
        ct[1] = ((d_n * up[7] - absx * up[10]) + rtb_Product1 * up[1]) + n * up
          [4];
        yd_idx_1 = ((d_n * up[10] + absx * up[7]) - rtb_Product1 * up[4]) + n *
          up[1];
        arg_idx_2 = ((d_n * up[2] - absx * up[5]) - rtb_Product1 * up[8]) - n *
          up[11];
        st[2] = ((d_n * up[5] + absx * up[2]) + rtb_Product1 * up[11]) - n * up
          [8];
        ct[2] = ((d_n * up[8] - absx * up[11]) + rtb_Product1 * up[2]) + n * up
          [5];
        yd_idx_2 = ((d_n * up[11] + absx * up[8]) - rtb_Product1 * up[5]) + n *
          up[2];
        up_tmp = ((arg_idx_0 * -absx + st[0] * d_n) + ct[0] * -n) - yd_idx_0 *
          -rtb_Product1;
        up_tmp_0 = ((arg_idx_0 * -rtb_Product1 - st[0] * -n) + ct[0] * d_n) +
          yd_idx_0 * -absx;
        up_tmp_1 = ((arg_idx_0 * -n + st[0] * -rtb_Product1) - ct[0] * -absx) +
          yd_idx_0 * d_n;
        up[0] = ((arg_idx_0 * d_n - st[0] * -absx) - ct[0] * -rtb_Product1) -
          yd_idx_0 * -n;
        up[3] = up_tmp;
        up[6] = up_tmp_0;
        up[9] = up_tmp_1;
        up_tmp_2 = ((arg_idx_1 * -absx + st[1] * d_n) + ct[1] * -n) - yd_idx_1 *
          -rtb_Product1;
        up_tmp_3 = ((arg_idx_1 * -rtb_Product1 - st[1] * -n) + ct[1] * d_n) +
          yd_idx_1 * -absx;
        up_tmp_4 = ((arg_idx_1 * -n + st[1] * -rtb_Product1) - ct[1] * -absx) +
          yd_idx_1 * d_n;
        up[1] = ((arg_idx_1 * d_n - st[1] * -absx) - ct[1] * -rtb_Product1) -
          yd_idx_1 * -n;
        up[4] = up_tmp_2;
        up[7] = up_tmp_3;
        up[10] = up_tmp_4;
        ct_0 = ((arg_idx_2 * -absx + st[2] * d_n) + ct[2] * -n) - yd_idx_2 *
          -rtb_Product1;
        up_tmp_5 = ((arg_idx_2 * -rtb_Product1 - st[2] * -n) + ct[2] * d_n) +
          yd_idx_2 * -absx;
        b_tmp = ((arg_idx_2 * -n + st[2] * -rtb_Product1) - ct[2] * -absx) +
          yd_idx_2 * d_n;
        up[2] = ((arg_idx_2 * d_n - st[2] * -absx) - ct[2] * -rtb_Product1) -
          yd_idx_2 * -n;
        up[5] = ct_0;
        up[8] = up_tmp_5;
        up[11] = b_tmp;
        for (b_k = 0; b_k < 3; b_k++) {
          q_tmp = (b_k + 1) * 3;
          q[3 * b_k] = up[q_tmp];
          q[3 * b_k + 1] = up[q_tmp + 1];
          q[3 * b_k + 2] = up[q_tmp + 2];
        }

        // :  m = [sqrt(q(1,1)^2+q(1,2)^2) sqrt(q(2,1)^2+q(2,2)^2) sqrt(q(3,1)^2+q(3,2)^2)]; 
        yd_idx_0 = std::sqrt(q[0] * q[0] + q[3] * q[3]);
        yd_idx_2 = std::sqrt(q[1] * q[1] + q[4] * q[4]);
        yd_idx_1 = std::sqrt(q[2] * q[2] + q[5] * q[5]);

        // :  if min(abs(m)) == 0
        st[0] = yd_idx_0;
        st[1] = yd_idx_2;
        st[2] = yd_idx_1;
        if (minimum(st) == 0.0) {
          // :  cycles = -1;
          idx = -1;
          guard1 = true;
          exitg2 = 1;
        } else {
          // :  arg = [(PQ(1)-Pz(1)*q(1,3))/m(1); (PQ(2)-Pz(2)*q(2,3))/m(2); (PQ(3)-Pz(3)*q(3,3))/m(3)]; 
          ct[0] = (0.5 - -0.57735026918962573 * up_tmp_1) / yd_idx_0;
          ct[1] = (0.087155742747658166 - -0.57735026918962573 * up_tmp_4) /
            yd_idx_2;
          ct[2] = (-0.49999999999999994 - -0.57735026918962573 * b_tmp) /
            yd_idx_1;

          // :  if max(abs(arg)) > 1.0
          st[0] = std::abs(ct[0]);
          st[1] = std::abs(ct[1]);
          st[2] = std::abs(ct[2]);
          if (maximum(st) > 1.0) {
            // :  cycles = -2;
            idx = -2;
            guard1 = true;
            exitg2 = 1;
          } else {
            // :  theta = atan2d(q(:,2),q(:,1))+[90; 90; 90;]-asind(arg);
            // :  theta_err = theta_meas-theta;
            // :  for k=1:3
            // :  if max(abs(theta_err)) < 0.01
            ct[0] = 57.295779513082323 * std::asin(ct[0]);
            arg_idx_0 = (57.295779513082323 * rt_atan2d_snf(q[3], q[0]) + 90.0)
              - ct[0];

            // :  while theta_err(k) > 180.0
            for (yd_idx_0 = rtU.theta_meas[0] - arg_idx_0; yd_idx_0 > 180.0;
                 yd_idx_0 -= 360.0) {
              // :  theta_err(k) = theta_err(k) - 360.0;
            }

            // :  while theta_err(k) < -180.0
            while (yd_idx_0 < -180.0) {
              // :  theta_err(k) = theta_err(k) + 360.0;
              yd_idx_0 += 360.0;
            }

            st[0] = std::abs(yd_idx_0);
            ct[1] = 57.295779513082323 * std::asin(ct[1]);
            arg_idx_1 = (57.295779513082323 * rt_atan2d_snf(q[4], q[1]) + 90.0)
              - ct[1];

            // :  while theta_err(k) > 180.0
            for (yd_idx_1 = rtU.theta_meas[1] - arg_idx_1; yd_idx_1 > 180.0;
                 yd_idx_1 -= 360.0) {
              // :  theta_err(k) = theta_err(k) - 360.0;
            }

            // :  while theta_err(k) < -180.0
            while (yd_idx_1 < -180.0) {
              // :  theta_err(k) = theta_err(k) + 360.0;
              yd_idx_1 += 360.0;
            }

            st[1] = std::abs(yd_idx_1);
            ct[2] = 57.295779513082323 * std::asin(ct[2]);
            arg_idx_2 = (57.295779513082323 * rt_atan2d_snf(q[5], q[2]) + 90.0)
              - ct[2];

            // :  while theta_err(k) > 180.0
            for (yd_idx_2 = rtU.theta_meas[2] - arg_idx_2; yd_idx_2 > 180.0;
                 yd_idx_2 -= 360.0) {
              // :  theta_err(k) = theta_err(k) - 360.0;
            }

            // :  while theta_err(k) < -180.0
            while (yd_idx_2 < -180.0) {
              // :  theta_err(k) = theta_err(k) + 360.0;
              yd_idx_2 += 360.0;
            }

            st[2] = std::abs(yd_idx_2);
            if (maximum(st) < 0.01) {
              // :  T = normalize(T);
              d_n = std::sqrt(((rtDW.T.a * rtDW.T.a + rtDW.T.b * rtDW.T.b) +
                               rtDW.T.c * rtDW.T.c) + rtDW.T.d * rtDW.T.d);
              rtDW.T.a /= d_n;
              rtDW.T.b /= d_n;
              rtDW.T.c /= d_n;
              rtDW.T.d /= d_n;

              // :  attitude = compact(T);
              absx = rtDW.T.a;
              yd_idx_2 = rtDW.T.b;
              yd_idx_1 = rtDW.T.c;
              yd_idx_0 = rtDW.T.d;

              // :  singularity = singularity_reg;
              rtY.singularity = rtDW.singularity_reg;
              exitg2 = 1;
            } else {
              int8_T b_n;

              // :  p = [cosd(theta) sind(theta) Pz];
              if (rtIsInf(arg_idx_0) || rtIsNaN(arg_idx_0)) {
                q[0] = (rtNaN);
                q[3] = (rtNaN);
              } else {
                rtb_Product1 = rt_remd_snf(arg_idx_0, 360.0);
                d_n = rtb_Product1;
                absx = std::abs(rtb_Product1);
                if (absx > 180.0) {
                  if (rtb_Product1 > 0.0) {
                    d_n = rtb_Product1 - 360.0;
                  } else {
                    d_n = rtb_Product1 + 360.0;
                  }

                  absx = std::abs(d_n);
                }

                if (absx <= 45.0) {
                  d_n *= 0.017453292519943295;
                  b_n = 0;
                } else if (absx <= 135.0) {
                  if (d_n > 0.0) {
                    d_n = (d_n - 90.0) * 0.017453292519943295;
                    b_n = 1;
                  } else {
                    d_n = (d_n + 90.0) * 0.017453292519943295;
                    b_n = -1;
                  }
                } else if (d_n > 0.0) {
                  d_n = (d_n - 180.0) * 0.017453292519943295;
                  b_n = 2;
                } else {
                  d_n = (d_n + 180.0) * 0.017453292519943295;
                  b_n = -2;
                }

                switch (b_n) {
                 case 0:
                  q[0] = std::cos(d_n);
                  break;

                 case 1:
                  q[0] = -std::sin(d_n);
                  break;

                 case -1:
                  q[0] = std::sin(d_n);
                  break;

                 default:
                  q[0] = -std::cos(d_n);
                  break;
                }

                d_n = rtb_Product1;
                absx = std::abs(rtb_Product1);
                if (absx > 180.0) {
                  if (rtb_Product1 > 0.0) {
                    d_n = rtb_Product1 - 360.0;
                  } else {
                    d_n = rtb_Product1 + 360.0;
                  }

                  absx = std::abs(d_n);
                }

                if (absx <= 45.0) {
                  d_n *= 0.017453292519943295;
                  b_n = 0;
                } else if (absx <= 135.0) {
                  if (d_n > 0.0) {
                    d_n = (d_n - 90.0) * 0.017453292519943295;
                    b_n = 1;
                  } else {
                    d_n = (d_n + 90.0) * 0.017453292519943295;
                    b_n = -1;
                  }
                } else if (d_n > 0.0) {
                  d_n = (d_n - 180.0) * 0.017453292519943295;
                  b_n = 2;
                } else {
                  d_n = (d_n + 180.0) * 0.017453292519943295;
                  b_n = -2;
                }

                switch (b_n) {
                 case 0:
                  q[3] = std::sin(d_n);
                  break;

                 case 1:
                  q[3] = std::cos(d_n);
                  break;

                 case -1:
                  q[3] = -std::cos(d_n);
                  break;

                 default:
                  q[3] = -std::sin(d_n);
                  break;
                }
              }

              if (rtIsInf(arg_idx_1) || rtIsNaN(arg_idx_1)) {
                q[1] = (rtNaN);
                q[4] = (rtNaN);
              } else {
                arg_idx_0 = rt_remd_snf(arg_idx_1, 360.0);
                d_n = arg_idx_0;
                absx = std::abs(arg_idx_0);
                if (absx > 180.0) {
                  if (arg_idx_0 > 0.0) {
                    d_n = arg_idx_0 - 360.0;
                  } else {
                    d_n = arg_idx_0 + 360.0;
                  }

                  absx = std::abs(d_n);
                }

                if (absx <= 45.0) {
                  d_n *= 0.017453292519943295;
                  b_n = 0;
                } else if (absx <= 135.0) {
                  if (d_n > 0.0) {
                    d_n = (d_n - 90.0) * 0.017453292519943295;
                    b_n = 1;
                  } else {
                    d_n = (d_n + 90.0) * 0.017453292519943295;
                    b_n = -1;
                  }
                } else if (d_n > 0.0) {
                  d_n = (d_n - 180.0) * 0.017453292519943295;
                  b_n = 2;
                } else {
                  d_n = (d_n + 180.0) * 0.017453292519943295;
                  b_n = -2;
                }

                switch (b_n) {
                 case 0:
                  q[1] = std::cos(d_n);
                  break;

                 case 1:
                  q[1] = -std::sin(d_n);
                  break;

                 case -1:
                  q[1] = std::sin(d_n);
                  break;

                 default:
                  q[1] = -std::cos(d_n);
                  break;
                }

                d_n = arg_idx_0;
                absx = std::abs(arg_idx_0);
                if (absx > 180.0) {
                  if (arg_idx_0 > 0.0) {
                    d_n = arg_idx_0 - 360.0;
                  } else {
                    d_n = arg_idx_0 + 360.0;
                  }

                  absx = std::abs(d_n);
                }

                if (absx <= 45.0) {
                  d_n *= 0.017453292519943295;
                  b_n = 0;
                } else if (absx <= 135.0) {
                  if (d_n > 0.0) {
                    d_n = (d_n - 90.0) * 0.017453292519943295;
                    b_n = 1;
                  } else {
                    d_n = (d_n + 90.0) * 0.017453292519943295;
                    b_n = -1;
                  }
                } else if (d_n > 0.0) {
                  d_n = (d_n - 180.0) * 0.017453292519943295;
                  b_n = 2;
                } else {
                  d_n = (d_n + 180.0) * 0.017453292519943295;
                  b_n = -2;
                }

                switch (b_n) {
                 case 0:
                  q[4] = std::sin(d_n);
                  break;

                 case 1:
                  q[4] = std::cos(d_n);
                  break;

                 case -1:
                  q[4] = -std::cos(d_n);
                  break;

                 default:
                  q[4] = -std::sin(d_n);
                  break;
                }
              }

              if (rtIsInf(arg_idx_2) || rtIsNaN(arg_idx_2)) {
                rtb_Product1 = (rtNaN);
                arg_idx_0 = (rtNaN);
              } else {
                d_n = rt_remd_snf(arg_idx_2, 360.0);
                absx = std::abs(d_n);
                if (absx > 180.0) {
                  if (d_n > 0.0) {
                    d_n -= 360.0;
                  } else {
                    d_n += 360.0;
                  }

                  absx = std::abs(d_n);
                }

                if (absx <= 45.0) {
                  d_n *= 0.017453292519943295;
                  b_n = 0;
                } else if (absx <= 135.0) {
                  if (d_n > 0.0) {
                    d_n = (d_n - 90.0) * 0.017453292519943295;
                    b_n = 1;
                  } else {
                    d_n = (d_n + 90.0) * 0.017453292519943295;
                    b_n = -1;
                  }
                } else if (d_n > 0.0) {
                  d_n = (d_n - 180.0) * 0.017453292519943295;
                  b_n = 2;
                } else {
                  d_n = (d_n + 180.0) * 0.017453292519943295;
                  b_n = -2;
                }

                switch (b_n) {
                 case 0:
                  rtb_Product1 = std::cos(d_n);
                  break;

                 case 1:
                  rtb_Product1 = -std::sin(d_n);
                  break;

                 case -1:
                  rtb_Product1 = std::sin(d_n);
                  break;

                 default:
                  rtb_Product1 = -std::cos(d_n);
                  break;
                }

                d_n = rt_remd_snf(arg_idx_2, 360.0);
                absx = std::abs(d_n);
                if (absx > 180.0) {
                  if (d_n > 0.0) {
                    d_n -= 360.0;
                  } else {
                    d_n += 360.0;
                  }

                  absx = std::abs(d_n);
                }

                if (absx <= 45.0) {
                  d_n *= 0.017453292519943295;
                  b_n = 0;
                } else if (absx <= 135.0) {
                  if (d_n > 0.0) {
                    d_n = (d_n - 90.0) * 0.017453292519943295;
                    b_n = 1;
                  } else {
                    d_n = (d_n + 90.0) * 0.017453292519943295;
                    b_n = -1;
                  }
                } else if (d_n > 0.0) {
                  d_n = (d_n - 180.0) * 0.017453292519943295;
                  b_n = 2;
                } else {
                  d_n = (d_n + 180.0) * 0.017453292519943295;
                  b_n = -2;
                }

                switch (b_n) {
                 case 0:
                  arg_idx_0 = std::sin(d_n);
                  break;

                 case 1:
                  arg_idx_0 = std::cos(d_n);
                  break;

                 case -1:
                  arg_idx_0 = -std::cos(d_n);
                  break;

                 default:
                  arg_idx_0 = -std::sin(d_n);
                  break;
                }
              }

              // :  q1xp1 = cross(q(1,:),p(1,:));
              arg_idx_2 = up_tmp * q[3] - q[0] * up_tmp_0;

              // :  q2xp2 = cross(q(2,:),p(2,:));
              ct[2] = up_tmp_2 * q[4] - q[1] * up_tmp_3;

              // :  q3xp3 = cross(q(3,:),p(3,:));
              d_n = ct_0 * arg_idx_0 - rtb_Product1 * up_tmp_5;

              // :  if min(abs([q1xp1(3) q2xp2(3) q3xp3(3)])) == 0.0
              st[0] = std::abs(arg_idx_2);
              st[1] = std::abs(ct[2]);
              st[2] = std::abs(d_n);
              if (minimum(st) == 0.0) {
                // :  cycles = -3;
                idx = -3;
                guard1 = true;
                exitg2 = 1;
              } else {
                // :  if det([q1xp1/q1xp1(3); q2xp2/q2xp2(3); q3xp3/q3xp3(3)]) == 0.0 
                absx = (up_tmp_0 * -0.57735026918962573 - q[3] * up_tmp_1) /
                  arg_idx_2;
                b[0] = absx;
                n = (up_tmp_3 * -0.57735026918962573 - q[4] * up_tmp_4) / ct[2];
                b[1] = n;
                up_tmp_5 = (up_tmp_5 * -0.57735026918962573 - arg_idx_0 * b_tmp)
                  / d_n;
                b[2] = up_tmp_5;
                up_tmp = (q[0] * up_tmp_1 - up_tmp * -0.57735026918962573) /
                  arg_idx_2;
                b[3] = up_tmp;
                up_tmp_2 = (q[1] * up_tmp_4 - up_tmp_2 * -0.57735026918962573) /
                  ct[2];
                b[4] = up_tmp_2;
                ct_0 = (rtb_Product1 * b_tmp - ct_0 * -0.57735026918962573) /
                  d_n;
                b[5] = ct_0;
                b_tmp = arg_idx_2 / arg_idx_2;
                b[6] = b_tmp;
                arg_idx_2 = ct[2] / ct[2];
                b[7] = arg_idx_2;
                d_n /= d_n;
                b[8] = d_n;
                if (det(b) == 0.0) {
                  // :  cycles = -4;
                  idx = -4;
                  guard1 = true;
                  exitg2 = 1;
                } else {
                  // :  T = quaternion(([q1xp1/q1xp1(3); q2xp2/q2xp2(3); q3xp3/q3xp3(3)]\(0.02*theta_err))','rotvec')*T; 
                  b[0] = absx;
                  b[1] = n;
                  b[2] = up_tmp_5;
                  st[0] = 0.02 * yd_idx_0;
                  b[3] = up_tmp;
                  b[4] = up_tmp_2;
                  b[5] = ct_0;
                  st[1] = 0.02 * yd_idx_1;
                  b[6] = b_tmp;
                  b[7] = arg_idx_2;
                  b[8] = d_n;
                  st[2] = 0.02 * yd_idx_2;
                  mldivide(b, st, ct);
                  d_n = 1.0;
                  absx = 0.0;
                  rtb_Product1 = 0.0;
                  n = 0.0;
                  yd_idx_1 = std::sqrt((ct[0] * ct[0] + ct[1] * ct[1]) + ct[2] *
                                       ct[2]);
                  yd_idx_0 = std::sin(yd_idx_1 / 2.0);
                  if (yd_idx_1 != 0.0) {
                    ct[0] = ct[0] / yd_idx_1 * yd_idx_0;
                    ct[1] = ct[1] / yd_idx_1 * yd_idx_0;
                    ct[2] = ct[2] / yd_idx_1 * yd_idx_0;
                    d_n = std::cos(yd_idx_1 / 2.0);
                    absx = ct[0];
                    rtb_Product1 = ct[1];
                    n = ct[2];
                  }

                  yd_idx_1 = rtDW.T.a;
                  yd_idx_0 = rtDW.T.b;
                  yd_idx_2 = rtDW.T.c;
                  rtDW.T.a = ((d_n * rtDW.T.a - absx * rtDW.T.b) - rtb_Product1 *
                              rtDW.T.c) - n * rtDW.T.d;
                  rtDW.T.b = ((d_n * rtDW.T.b + absx * yd_idx_1) + rtb_Product1 *
                              rtDW.T.d) - n * rtDW.T.c;
                  rtDW.T.c = ((d_n * rtDW.T.c - absx * rtDW.T.d) + rtb_Product1 *
                              yd_idx_1) + n * yd_idx_0;
                  rtDW.T.d = ((d_n * rtDW.T.d + absx * yd_idx_2) - rtb_Product1 *
                              yd_idx_0) + n * yd_idx_1;
                  b_cycles++;
                  guard1 = false;
                }
              }
            }
          }
        }
      } else {
        guard1 = true;
        exitg2 = 1;
      }
    } while (exitg2 == 0);

    if (guard1) {
      // :  T = quaternion(1,0,0,0);
      rtDW.T.a = 1.0;
      rtDW.T.b = 0.0;
      rtDW.T.c = 0.0;
      rtDW.T.d = 0.0;

      // :  attitude = compact(T);
      absx = rtDW.T.a;
      yd_idx_2 = rtDW.T.b;
      yd_idx_1 = rtDW.T.c;
      yd_idx_0 = rtDW.T.d;

      // :  singularity_reg = 1;
      rtDW.singularity_reg = 1.0;

      // :  singularity = singularity_reg;
      rtY.singularity = 1.0;
    }
  }

  // Sqrt: '<S12>/sqrt' incorporates:
  //   Product: '<S13>/Product'
  //   Product: '<S13>/Product1'
  //   Product: '<S13>/Product2'
  //   Product: '<S13>/Product3'
  //   Sum: '<S13>/Sum'

  d_n = std::sqrt(((absx * absx + yd_idx_2 * yd_idx_2) + yd_idx_1 * yd_idx_1) +
                  yd_idx_0 * yd_idx_0);

  // Product: '<S7>/Product'
  absx /= d_n;

  // Product: '<S7>/Product1'
  rtb_Product1 = yd_idx_2 / d_n;

  // Product: '<S7>/Product2'
  n = yd_idx_1 / d_n;

  // Product: '<S7>/Product3'
  d_n = yd_idx_0 / d_n;

  // Fcn: '<S4>/fcn3'
  yd_idx_1 = (rtb_Product1 * d_n - absx * n) * -2.0;

  // Fcn: '<S4>/fcn2' incorporates:
  //   Fcn: '<S4>/fcn5'

  yd_idx_0 = absx * absx;
  yd_idx_2 = rtb_Product1 * rtb_Product1;
  ct_0 = n * n;
  b_tmp = d_n * d_n;

  // Outport: '<Root>/ypr_meas' incorporates:
  //   Fcn: '<S4>/fcn1'
  //   Fcn: '<S4>/fcn2'
  //   Gain: '<S2>/Gain3'
  //   Trigonometry: '<S6>/Trigonometric Function1'

  rtY.ypr_meas[0] = rt_atan2d_snf((rtb_Product1 * n + absx * d_n) * 2.0,
    ((yd_idx_0 + yd_idx_2) - ct_0) - b_tmp) * 57.295779513082323;

  // If: '<S8>/If' incorporates:
  //   Constant: '<S10>/Constant'
  //   Constant: '<S9>/Constant'
  //   Gain: '<S2>/Gain3'
  //   Outport: '<Root>/ypr_meas'
  //   Trigonometry: '<S6>/trigFcn'

  if (yd_idx_1 > 1.0) {
    // Outputs for IfAction SubSystem: '<S8>/If Action Subsystem' incorporates:
    //   ActionPort: '<S9>/Action Port'

    yd_idx_1 = 1.0;

    // End of Outputs for SubSystem: '<S8>/If Action Subsystem'
  } else if (yd_idx_1 < -1.0) {
    // Outputs for IfAction SubSystem: '<S8>/If Action Subsystem1' incorporates:
    //   ActionPort: '<S10>/Action Port'

    yd_idx_1 = 1.0;

    // End of Outputs for SubSystem: '<S8>/If Action Subsystem1'
  }

  rtY.ypr_meas[1] = 57.295779513082323 * std::asin(yd_idx_1);

  // End of If: '<S8>/If'

  // Outport: '<Root>/ypr_meas' incorporates:
  //   Fcn: '<S4>/fcn4'
  //   Fcn: '<S4>/fcn5'
  //   Gain: '<S2>/Gain3'
  //   Trigonometry: '<S6>/Trigonometric Function3'

  rtY.ypr_meas[2] = rt_atan2d_snf((n * d_n + absx * rtb_Product1) * 2.0,
    ((yd_idx_0 - yd_idx_2) - ct_0) + b_tmp) * 57.295779513082323;

  // Outport: '<Root>/cycles' incorporates:
  //   MATLAB Function: '<S2>/motors2quat'

  rtY.cycles = idx;

  // End of Outputs for SubSystem: '<S1>/motors2ypr'
  // End of Outputs for SubSystem: '<Root>/wrist_decoupler'
}

// Model initialize function
void wrist_decoupler::initialize()
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // SystemInitialize for Atomic SubSystem: '<Root>/wrist_decoupler'
  // SystemInitialize for Atomic SubSystem: '<S1>/motors2ypr'
  // SystemInitialize for MATLAB Function: '<S2>/motors2quat'
  // :  T = quaternion(1,0,0,0);
  rtDW.T.a = 1.0;
  rtDW.T.b = 0.0;
  rtDW.T.c = 0.0;
  rtDW.T.d = 0.0;

  // End of SystemInitialize for SubSystem: '<S1>/motors2ypr'
  // End of SystemInitialize for SubSystem: '<Root>/wrist_decoupler'
  // :  singularity_reg = 0;
}

// Constructor
wrist_decoupler::wrist_decoupler() :
  rtU(),
  rtY(),
  rtDW(),
  rtM()
{
  // Currently there is no constructor body generated.
}

// Destructor
wrist_decoupler::~wrist_decoupler()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
wrist_decoupler::RT_MODEL * wrist_decoupler::getRTM()
{
  return (&rtM);
}

//
// File trailer for generated code.
//
// [EOF]
//
