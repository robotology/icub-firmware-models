//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
//
// File: wrist_decoupler_data.cpp
//
// Code generated for Simulink model 'wrist_decoupler'.
//
// Model version                  : 6.6
// Simulink Coder version         : 9.8 (R2022b) 13-May-2022
// C/C++ source code generated on : Fri Mar 24 10:28:52 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "wrist_decoupler.h"

// Constant parameters (default storage)
const wrist_decoupler::ConstP rtConstP = {
  // Pooled Parameter (Expression: Q)
  //  Referenced by:
  //    '<S1>/ypr2motors'
  //    '<S2>/motors2quat'

  { 0.087155742747658166, -0.99619469809174555, 0.17364817766693033,
    0.99619469809174555, -0.087155742747658166, -0.984807753012208, 0.0, 0.0,
    0.0 }
};

//
// File trailer for generated code.
//
// [EOF]
//
